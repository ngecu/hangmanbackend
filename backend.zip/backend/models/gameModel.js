import mongoose from 'mongoose';

const gameSchema = mongoose.Schema({
  User: {
    type: mongoose.Schema.Types.ObjectId,
    required: true,
    ref: 'User',
  },

  
  score: {
    type: Number,
    required: true,
  },

  highest_score: {
    type: Number,
    required: true,
  }

},
{
  timestamps: true,
}

);

const Game = mongoose.model('Game', gameSchema);

export default Game;
